
var itemList = [];

const content = require('fs').readFileSync(__dirname + '/main.html', 'utf8');

const httpServer = require('http').createServer((req, res) => {
    res.setHeader('Content-Type', 'text/html');
    res.setHeader('Content-Length', Buffer.byteLength(content));
    res.end(content);
});

const io = require('socket.io')(httpServer);

for (var i = 0; i < 10; i++) {
    itemList.push(i)
}

io.on('connect', socket => {
    socket.emit('', itemList);

    socket.on('', (DATA_RECEIVED_FROM_HTML) => {
        console.log(DATA_RECEIVED_FROM_HTML);
    });
});


httpServer.listen(3000, () => {
    console.log('go to http://localhost:3000');
})